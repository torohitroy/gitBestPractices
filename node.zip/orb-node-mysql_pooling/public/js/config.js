var port = '3002';
var hostname = 'orbstg.sourcefuse.com:';
var branch_io_key = 'key_live_hcuoiab25S8rA9RSO1H0ralhxFnir1qz';
var ios_app_link = 'Orb://';
var android_link = 'Orb://open';