var port = '3002';
var email = 'justorbmi@gmail.com';
var password = 'justorbmi123';
var transport_method = 'GMAIL';
var hostname = 'orbstg.sourcefuse.com:';
//var hostname = 'localhost:';
var config = {
    development: {
        mode: 'development',
        port: port,                           
        mysql: {
            host: 'localhost',
            user: 'orbdbuser',                           //orbmeuser
            pass: 'SnIy5$NC89335dR0wp',                                   //Uzd6prScfWnLc1Z
            dbname: 'orbdb_issue'                        //orbme2
        },
        s3: {
            S3_KEY: 'AKIAJQ7MPHSWC4ZIFLFA',
            S3_SECRET: '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',
            BUCKET: 'orbmitranscoder',
            ENDPOINT: 's3.amazonaws.com'
        },
        server_details: {
            host: hostname + port +'/'      
        },
        email_details: {
            username: email,
            password: password,
            from: email,
            transport_method: transport_method
        },
        email_config: {
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        auth: {
                user: email,
                pass: password
            }
        }
    },
    staging: {
        mode: 'staging',
        port: '4000'
    },
    production: {
        mode: 'production',
        port: '5000'
    }
};

module.exports = function (mode) {
    return config[mode || process.argv[2] || 'development'] || config.development;
};