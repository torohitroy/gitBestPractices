module.exports = {
    name: "GenericMiddleware",
    content: "null",
    abc: function () {
        console.log("i am abc middleware");
    }
};